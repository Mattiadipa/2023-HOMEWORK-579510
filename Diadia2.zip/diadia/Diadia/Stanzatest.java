import static org.junit.Assert.*;

import org.junit.Test;
import it.uniroma3.diadia.*;
import it.uniroma3.diadia.ambienti.*;
import it.uniroma3.diadia.attrezzi.*;
import it.uniroma3.diadia.giocatore.*;
public class Stanzatest {

	@Test
	public void testaddattrezzo() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		assertEquals(true,partita.getStanzacorrente().addAttrezzo(attrezzo));
	}
	
	@Test
	public void testaddattrezzo2() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		Attrezzo attrezzo2=new Attrezzo("spada",3);	
	   assertEquals(true,partita.getStanzacorrente().addAttrezzo(attrezzo));
	   assertEquals(true,partita.getStanzacorrente().addAttrezzo(attrezzo2));
	
	}  
	
	
	
	
	@Test
	public void testaremoveattrezzo() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		partita.getStanzacorrente().addAttrezzo(attrezzo);
		assertEquals(true,partita.getStanzacorrente().removeAttrezzo(attrezzo));
	}
	
	
	@Test
	public void testaremoveattrezzo2() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		Attrezzo attrezzo2=new Attrezzo("pistola",3);
		partita.getStanzacorrente().addAttrezzo(attrezzo);
		partita.getStanzacorrente().addAttrezzo(attrezzo2);
		assertEquals(true,partita.getStanzacorrente().removeAttrezzo(attrezzo));
		assertEquals(true,partita.getStanzacorrente().removeAttrezzo(attrezzo2));
		
	}
	
	public void testaremoveattrezzo3() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		Attrezzo attrezzo2=new Attrezzo("pistola",3);
		Attrezzo attrezzo3= new Attrezzo("spada",5);
	    partita.getStanzacorrente().addAttrezzo(attrezzo);
		partita.getStanzacorrente().addAttrezzo(attrezzo2);
		partita.getStanzacorrente().addAttrezzo(attrezzo3);
		assertEquals(true,partita.getStanzacorrente().removeAttrezzo(attrezzo));
		assertEquals(true,partita.getStanzacorrente().removeAttrezzo(attrezzo2));
		
	}
	//@Test
	/**public void testahasattrezzo() {
		Partita partita = new Partita();	
		Attrezzo attrezzo= new Attrezzo("lanterna",2);
		partita.getStanzacorrente().addAttrezzo(attrezzo);
		String attrezzocercato=attrezzo.toString();
		assertEquals(true,partita.getStanzacorrente().hasAttrezzo(attrezzocercato));

}
*/
}
