package it.uniroma3.diadia;

/**
import static org.junit.Assert.*;

import org.junit.Test;
import it.uniroma3.diadia.*;
public class partitatest {

	@Test
	public void test() {
	Partita partita=new Partita();
	}

}
/*