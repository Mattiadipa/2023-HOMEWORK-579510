package it.uniroma3.diadia.ambienti;
import it.uniroma3.diadia.*;
import it.uniroma3.diadia.ambienti.*;
import it.uniroma3.diadia.attrezzi.*;
import it.uniroma3.diadia.giocatore.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class Partitatest {

	@Test
	public void setfinita() {
		Partita partita= new Partita();
		assertEquals(false,partita);
	}

}
