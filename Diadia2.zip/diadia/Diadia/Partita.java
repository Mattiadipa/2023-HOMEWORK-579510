

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Giocatore;

/**
 * Questa classe modella una partita del gioco
 *
 * @author  docente di POO
 * @see Stanza
 * @version base
 */

public class Partita {

	private boolean finita;
	private Labirinto labirinto;
	private Giocatore giocatore; 
	private Stanza Stanzavincente;
    public Stanza stanzacorrente;
	
	
	public Partita(){
		this.finita = false;
		this.labirinto=new Labirinto();
		this.giocatore=new Giocatore();
		this.stanzacorrente=labirinto.getStanzaIniziale();
		this.Stanzavincente=labirinto.getStanzaFinale();
	}
    
    
	/**
	 * Restituisce vero se e solo se la partita e' stata vinta
	 * @return vero se partita vinta
	 */
	public boolean vinta() {
		
		return this.getStanzacorrente().equals(this.getStanzaVincente()) ;
	}

	/*private Object getStanzaCorrente() {
		// TODO Auto-generated method stub
		return null;
	}
*/
	/**
	 * Restituisce vero se e solo se la partita e' finita
	 * @return vero se partita finita
	 */
	public boolean isFinita() {
		return finita || vinta() || (giocatore.getCfu() == 0);
	}

	/**
	 * Imposta la partita come finita
	 *
	 */
	public void setFinita() {
		this.finita = true;
	}


	public Labirinto getLabirinto() {
		return labirinto;
	}


	public void setLabirinto(Labirinto labirinto) {
		this.labirinto = labirinto;
	}


	public Giocatore getGiocatore() {
		return giocatore;
	}


	public void setGiocatore(Giocatore giocatore) {
		this.giocatore = giocatore;
	}


	public Stanza getStanzaVincente() {
		return Stanzavincente;
	}


	public void setStanzaVincente(Stanza stanzaFinale) {
		Stanzavincente = stanzaFinale;
	}


	public Stanza getStanzacorrente() {
		return stanzacorrente;
	}


	public void setStanzacorrente(Stanza stanzacorrente) {
		this.stanzacorrente = stanzacorrente;
	}

	
}
