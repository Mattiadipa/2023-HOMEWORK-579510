package test;

import static org.junit.Assert.*;

import org.junit.Test;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class StanzaTest {

	@Test
	/**public void testremoveAttrezzo() {
		Partita partita=new Partita();
		Stanza stanza=new Stanza("atrio");
		Attrezzo attrezzo=new Attrezzo("osso",1);
		partita.getStanzacorrente().addAttrezzo(attrezzo);
		partita.getStanzacorrente().removeAttrezzo(attrezzo);
		assertEquals(true,stanza.removeAttrezzo(attrezzo));
	}
*/
	//@Test
	public void testaddAttrezzo() {	
		Partita partita=new Partita();
		Stanza stanza=new Stanza("atrio");
		Attrezzo attrezzo=new Attrezzo("osso",1);
		partita.getStanzacorrente().addAttrezzo(attrezzo);
		assertEquals(true,stanza.addAttrezzo(attrezzo));
    
    
		
	}

	@Test
	public void testHasAttrezzo() {
    Partita partita=new Partita();
    Stanza stanza=new Stanza("atrio");
	Attrezzo attrezzo=new Attrezzo("osso",1);
	partita.getStanzacorrente().addAttrezzo(attrezzo);
	assertEquals(true,stanza.hasAttrezzo(attrezzo.getNome()));
	}

}
